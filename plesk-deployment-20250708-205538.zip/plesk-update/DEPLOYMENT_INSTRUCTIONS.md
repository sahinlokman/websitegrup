# Plesk Dağıtım Talimatları

## Son Değişiklikler (2025-01-08)

Bu paket aşağıdaki değişiklikleri içerir:

### Değiştirilen Dosyalar:
- `src/components/CategoryPage.tsx`
- `src/components/GroupList.tsx`
- `src/components/TopGroupsPage.tsx`
- `src/components/admin/AdminDashboard.tsx`
- `src/components/admin/UserManagement.tsx`
- `src/components/auth/RegisterModal.tsx`
- `src/services/supabaseService.ts`

### Yeni Dosyalar:
- `supabase/migrations/20250108000000_add_public_user_functions.sql`

## Dağıtım Adımları:

### 1. Statik Dosyalar (Web Sunucusu için)
- `dist/` klasörünün içeriğini web sitenizin kök dizinine yükleyin
- Bu klasör build edilmiş production dosyalarını içerir

### 2. Kaynak Kodlar (Yedekleme/Referans için)
- `src/` klasörü güncellenmiş kaynak kodları içerir
- Gelecekteki geliştirmeler için referans olarak kullanılabilir

### 3. Veritabanı Migration'ları
- `supabase/migrations/20250108000000_add_public_user_functions.sql` dosyasını Supabase üzerinde çalıştırın
- Bu yeni kullanıcı fonksiyonlarını ekler

### 4. Bağımlılıklar
- Eğer sunucuda Node.js varsa, `npm install` çalıştırın
- `package.json` ve `package-lock.json` güncellenmiş bağımlılıkları içerir

## Önemli Notlar:
- Dağıtımdan önce mevcut dosyaları yedekleyin
- Supabase migration'ını çalıştırmayı unutmayın
- İndex.html dosyası ana sayfa olarak kullanılmalıdır

## Test:
- Dağıtımdan sonra sitenizin düzgün çalıştığını kontrol edin
- Kullanıcı kaydı ve admin paneli işlevlerini test edin 